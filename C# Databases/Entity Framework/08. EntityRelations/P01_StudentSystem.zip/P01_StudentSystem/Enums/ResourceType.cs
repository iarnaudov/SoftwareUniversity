﻿namespace P01_StudentSystem.Enums
{
    public enum ResourceType
    {
        Video,
        Presentation,
        Document,
        Other
    }
}