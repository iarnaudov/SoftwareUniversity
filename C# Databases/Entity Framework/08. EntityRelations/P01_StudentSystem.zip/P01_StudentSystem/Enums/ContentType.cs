﻿namespace P01_StudentSystem.Enums
{
    public enum ContentType
    {
        Application,
        Pdf,
        Zip
    }
}