﻿namespace P01_StudentSystem
{
    public static class Configuration
    {
        public const string ConnectionString = "Server=(localdb)\\MSSQLLocalDB;Database=StudentSystem;Integrated Security=true;";
    }
}