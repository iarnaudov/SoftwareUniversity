﻿namespace P03_FootballBetting.Data.Models.Enums
{
    public enum Result
    {
        Win,
        Lose,
        Draw
    }
}