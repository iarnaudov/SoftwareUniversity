﻿using System;
using System.Collections.Generic;
using System.Text;

namespace P01_HospitalDatabase.Data
{
    class Configuration
    {
        public const string ConnectionString = "Server=DESKTOP-RF7B1AL\\SQLEXPRESS;Database=Hospital;Integrated Security=True";
    }
}
